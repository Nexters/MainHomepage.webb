var contactController = angular.module('contactController', []);

contactController.controller('contactController',function ($scope) {
  // body...
  $scope.data="contact";
})
