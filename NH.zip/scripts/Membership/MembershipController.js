var membershipController = angular.module('membershipController', []);

membershipController.controller('membershipController',function ($scope) {
  // body...
  $scope.data="membership";
})
